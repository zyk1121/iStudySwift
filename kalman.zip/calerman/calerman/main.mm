
//
//  main.m
//  calerman
//
//  Created by wang liyong on 16/11/16.
//  Copyright © 2016年 wang liyong. All rights reserved.
//

#import <Foundation/Foundation.h>

#include "Kalman.h"
#import <stdlib.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
    Kalman *km = new Kalman(1e-3,1e-1);
    
    km->InitKalman(418878.396,144075.960);
    
    double lonlat[20][2]={{418878.396,144075.960},{418878.792,144075.384},{418879.188,144074.844},{418879.620,144074.268},{418879.980,144073.728 },{418880.412,144073.224 },{418880.844,144072.720 },{ 418881.240,144072.180},{418881.672,144071.676 },{ 418882.068,144071.136},{418882.500,144070.596},{418882.896,144070.092},{418883.364,144069.552},{418883.796,144069.012},{418884.228,144068.472},{418884.624,144067.932},{418885.056,144067.392},{418885.452,144066.888},{418885.956,144066.384},{418886.352,144065.844}};
    
    
    for (int i =0; i<20; i++) {
        printf("%.3f,%.3f,%d:0\n",km->measurement_value->buf[0],km->measurement_value->buf[1],i);
        km->PredictKalman();
        double preLon = km->state_pre->buf[0];
        double preLat = km->state_pre->buf[1];
        printf("%.3f,%.3f,%d:1\n",preLon,preLat,i);
        
        
        km->measurement_value->buf[0] =lonlat[i][0];
        km->measurement_value->buf[1] =lonlat[i][1];
        
        km->CorrectKalman();
        //        double corLon = km->state_pre->buf[0];
        //        double corLat = km->state_pre->buf[1];
        
        //        printf("corr:%.3f,%.3f,",corLon,corLat);
        //        km->PredictKalman();
        //
        //        double preLon1 = km->state_pre->buf[0];
        //        double preLat1 = km->state_pre->buf[1];
        //        printf("pred:%.3f,%.3f\n",preLon1,preLat1);
    }
    
    delete km;
    
    return 0;
}
