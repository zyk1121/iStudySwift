#include "Matrix.h"
//#include "general.h"
#include <math.h>
#include <cmath>
#include <exception>
#include <stdexcept>
#include <iostream>
#include <limits>
using namespace std;
//------------------------------ Implemenation  -----------------------------
Matrix::Matrix() //default constructor
{
	rows=columns=0;
	buf=NULL;
       // cout<<"call constructor"<<endl;
}
Matrix::Matrix( int m,  int n)//declare an mxn matrix
{
    if(!this->buf)delete[] this->buf;
    this->rows=m;
    this->columns=n;
    this->buf=new double[m*n];
	memset(this->buf,0,m*n*8);
    //cout<<"call constructor"<<endl;
}
//my defination attention array data 
//1D
Matrix::Matrix( int m,  int n,double *data)//declare an mxn matrix
{
	if(!this->buf)delete[] this->buf;
	this->rows=m;
	this->columns=n;
	this->buf=new double[m*n];
	//
	/*for (int i=0;i<m;i++)
	{
		for (int j=0;j<n;j++)
		{
			this->buf[i*m+j] = data[i*m+j];
		}
	}*/
	memcpy(this->buf,data,m*n*8);
	//cout<<"call constructor"<<endl;
}
////my defination

Matrix::Matrix(const Matrix& A) //copy constructor
{
     //                          Matrix C(C); ??????????? could not pass compile, don't worry
 
//      if(!this->buf)delete[] this->buf;
      this->rows=A.rows;
      this->columns=A.columns;
      this->buf=new double[(A.rows)*(A.columns)];
      int i;
      for(i=0;i<((A.rows)*(A.columns));i++)
        {
          this->buf[i]=A.buf[i];
        }
    //  cout<<"call copy construcotor"<<endl;
}
Matrix::~Matrix()//destructor
{
  delete[] this->buf;
  this->rows=0;
  this->columns=0;
 // cout<<"call destructor"<<endl;
}
//Assignment
Matrix& Matrix::operator = (const Matrix& A) //overloading =
{
        if(this==&A) return *this;
        if(!buf) delete[] buf;
        columns=A.columns;
        rows=A.rows;
        buf=new double[columns*rows];
        int i;
        for(i=0;i<(columns*rows);i++)
           {
            buf[i]=A.buf[i];
           }
	return *this;
}
//operators
bool Matrix::operator == (const Matrix& A)//overloading ==
{
	int i;
        if(!this->buf||!A.buf) 
            {
              cout<<"Two Empty Matrix"<<endl;
              return true;
            }
        if(this->columns!=A.columns||this->rows!=A.rows)
              return false;
        else
            {
             for(i=0;i<columns*rows;i++)
                 {
                  if(abs(this->buf[i]-A.buf[i])>1e-10) return false;
                 }

            }
        return true;
}
bool Matrix::operator != (const Matrix& A)//overloading !=
{
	return !(*this==A); //use ==
}
Matrix& Matrix::operator += (const Matrix& A) //overloading +=
{
        if(!A.buf) return *this;
        if ( (this->rows != A.rows) || (this->columns != A.columns))
	{
		//cerr << "Size mismatch in matrix addition" << endl;
		//throw logic_error ("Size mismatch in matrix addition");
	}
        for(int i=0;i<A.columns*A.rows;i++)
            this->buf[i]+=A.buf[i];

	return *this;
}
Matrix& Matrix::operator -=(const Matrix& A) //overloading -=
{
        if(!A.buf) return *this;
        if ( (this->rows != A.rows) || (this->columns != A.columns))
	{
		cerr << "Size mismatch in matrix addition" << endl;
		//throw logic_error ("Size mismatch in matrix addition");
	}
        for(int i=0;i<A.columns*A.rows;i++)
            this->buf[i]-=A.buf[i];
	return *this;
}
Matrix& Matrix::operator *=(const Matrix& A) //overloading *=
{
        if(!A.buf)    //throw logic_error (" You are Multipling Empty Matrix");
			cerr << "You are Multipling Empty Matrix" << endl;
        if(this->columns!=A.rows)   // throw logic_error ("Size Mismatch!");
			cerr << "Size Mismatch!" << endl;
        if(A.columns==0||A.rows==0||this->columns==0||this->rows==0)  //throw logic_error ("go check your weried matrix first");
			cerr << "go check your weried matrix first" << endl;
       // Matrix tmp(*this);
        //delete[] this->buf;
        //this->buf= new double[this->rows*A.columns];
        Matrix tmp(this->rows, A.columns);
	for (int i=1; i<=tmp.rows; i++)
	{
		for (int j=1; j<=tmp.columns; j++)
		{
			tmp(i,j) = 0;
			for (int k=1; k<=A.rows; k++)
				tmp(i,j) += (*this)(i,k) * A(k,j);
		}
	}
	*this = tmp;
	return *this;
}
Matrix& Matrix::operator *=(double a) //overloading *=
{
      	if(!this->buf)	//throw logic_error ("please Check your empty Matrix first");
			cerr << "please Check your empty Matrix first";
        for(int i=0;i<columns*rows;i++)
            {
             this->buf[i]*=a;
            }
	return *this;
}
Matrix Matrix::operator + () //unary +
{
	return *this; //good enough.
}
Matrix Matrix::operator - () //unary -
{
	if ((this->rows == 0) || (this->columns == 0) )
	{
		//throw invalid_argument ("Missing matrix data");
		cerr << "Missing matrix data";
	}
	Matrix tmp(this->rows, this->columns);
	for (int i=0; i<rows*columns; ++i)
	{
               tmp.buf[i]=-(this->buf[i]);
	}
	return tmp;
}
double& Matrix::operator ()( int i,  int j)// access (i,j)
{
        if(i>this->rows||j>this->columns)  // throw logic_error ("Matrix is not this big");
			cerr << "Matrix is not this big";
        if(i<=0||j<=0)	//throw logic_error ("can not access, your index is wrong");
			cerr << "can not access, your index is wrong";

	return buf[(i-1)*columns+(j-1)]; // is this correct? Unsafe
}
double& Matrix::operator()( int i,  int j) const //read only
{
	//return buf[i*columns+j]; // is this correct? Unsafe
	return buf[(i-1)*columns+(j-1)]; // is this correct? Unsafe

}
ostream& operator << (ostream& output, const Matrix& A) 
{

	for ( int i = 1; i <= A.rows; i++)
	{
		for ( int j = 1; j <= A.columns; j++)
			output << A(i,j) << "\t   ";
		output << endl; 
	}

	return output; 
}



//istream& operator >> (istream& input, Matrix& A) 
//{
//
//
//	if (input.fail())
//	{
//		throw runtime_error ("Error reading input");
//	}
//
//	BypassComment(input);
//	input >> A.rows;
//	BypassComment(input);
//	input >> A.columns;
//        cout<<A.rows<<"*"<<A.columns<<endl; // for debug
//
//
//	if (A.rows<=0 || A.columns<=0)
//	{
//		throw invalid_argument ("Invalid matrix data");
//	}
//        if (A.buf) delete[] A.buf;//check if A.buf=NULL, if not,delete A
//        A.buf=new double[A.rows*A.columns];
//	for (int i=1; i<=A.rows; i++)
//	{
//		for (int j=1; j<=A.columns; j++)
//		{
//			BypassComment(input);
//			input >> A(i,j);
//                        //cout<<A(i,j);
//		}
//	}
//
//	//use BypassComment to skip comments.
//
//	return input;
//}


//------------Member Functions------------------------------
Matrix Matrix::Adjugate() //Adjoint/Adjugate
{
    Matrix tmp;
    tmp=this->Cofactor();
    tmp=tmp.Transpose();
    return tmp;
}
double Matrix::Cofactor(int i, int j) //cofactor Cij
{
        double tmp;
        tmp=this->Minor(i,j);
        tmp=pow((double)(-1),(double)(i+j))*tmp;
//	double tmp;
	return tmp;
}
Matrix Matrix::Cofactor()//matrix of cofactors
{

	if(!this->buf)    //throw logic_error (" Empty Matrix ");
		cerr << "Empty Matrix";
	Matrix tmp(this->rows, this->columns); 
        for (int i=1;i<=this->rows;i++)
              {
                for (int j=1;j<=this->columns;j++)
                        {
                          tmp(i,j)=this->Cofactor(i,j);
                        }
              }
	return tmp;

}
double Matrix::Minor(int i, int j)//Minor Mij
{
        double tmp;
        Matrix A;
        A.rows=(this->rows)-1;
        A.columns=(this->columns)-1;
        A.buf=new double[A.rows*A.columns];
        int a=0;
          for(int m=1;m<=this->rows;m++)
              {
                for(int n=1;n<=this->columns;n++)
                   {
                      if(m==i) continue;
                      if(n==j) continue;
                      A.buf[a]=(*this)(m,n);
                      a++;
                   }
              }
        tmp=A.det(); 
		//delete[] A.buf;
        return tmp;

}
bool Matrix::IsSingular()
{
	//return (this->det()==0);  //may not work, because of double precision. you fix it.
         return (fabs(this->det()-0)<0.00000001); 
}
bool Matrix::IsSymmetric()
{
	return ((*this)==(this->Transpose()));
}
const int Matrix::GetRows() const
{
	return rows;
};

const int Matrix::GetColumns() const
{
	return columns; //
};
Matrix Matrix::Transpose()  //transpose
{
	//check size
	if ((this->GetRows() == 0) || (this->GetColumns() == 0) )
	{
		cerr << "Missing matrix data" << endl;
		//throw invalid_argument ("Missing matrix data");
	}
	
	Matrix tmp(this->GetColumns(), this->GetRows());
	for (int i=1; i<=tmp.GetRows(); ++i)
	{
		for (int j=1; j<=tmp.GetColumns(); ++j)
			tmp(i,j) = (*this)(j,i);
	}
	return tmp;
}
Matrix Matrix::Inverse()//Inverse Matrix
{
	Matrix tmp;
        if((*this).GetRows()!=(*this).GetColumns())
           {
			   //throw logic_error ("Solving for Inverse fail: Not a square    matrix!");
			   cerr << "Solving for Inverse fail: Not a square    matrix!";
            //return (*this);
           }
        if(fabs(this->det()-0)<0.000000001)
           {
             //throw logic_error ("determinant equal to zero, can not do inverse");
			   cerr << "determinant equal to zero, can not do inverse";
           }
        Matrix A;
        A=this->Adjugate();   
        tmp=(1/this->det())*A;
	return tmp;
}
Matrix Matrix::Null(int n) //make a "zero" Matrix, with a new dimension, change "this"
{
	this->rows=n;
	this->columns=n;
	this->buf=new double[n*n];
	for(int a=0;a<n;a++)
	{
		for(int b=0;b<n;b++)
			this->buf[a*this->columns+b]=0;  
	}

	return *this;
}
Matrix Matrix::Null()//make a "zero" Matrix, does not change the dimension, change "this"
{
	//if(this->GetRows()=0||this->GetColumns()=0) return false;
	for(int a=0;a< this->GetRows();a++)
	{
		for(int b=0;b< this->GetColumns();b++)
			this->buf[a*this->GetColumns()+b]=0;
	}
	return *this;
}
Matrix Matrix::Identity( int n)//make a nxn identity matrix,change "this"
{
       // if(n==0) return false;

        if(n<=0)
	    // throw invalid_argument ("argument has to be larger than 0");
			cerr << "argument has to be larger than 0";

	this->rows=n;
	this->columns=n;
	this->buf=new double[n*n];
	int a;
	int b;
	for(a=0;a< this->GetRows();a++)
	{
		for(b=0;b< this->GetRows();b++)
		{
			if(a==b)
				this->buf[a*n+b]=1;
		else
			this->buf[a*n+b]=0;
		}
        }
	return *this;
}
Matrix Matrix::Identity()//make a identity matrix, does not change the dimentsion, change "this"
{
	if(this->GetRows()!=this->GetColumns() || this->GetRows()==0)
	   	     //throw logic_error ("Check your matrix . Matrix has to be squre ");
				 cerr << "Check your matrix . Matrix has to be squre ";
	int a;
	int b;
	for(a=0;a<this->GetRows();a++)
	{
		for(b=0; b< this->GetColumns();b++)
		{
			if(a==b)
				this->buf[a*this->columns+b]=1;
		else
			this->buf[a*this->columns+b]=0;
		}
	}
	return *this;
}
bool Matrix::LU(Matrix& L, Matrix& U)//LU decomposition. return true if successful
{
/*

*/

if(this->rows!=this->columns)   //LU decomposition only can be operated on square Matrix
    {
       cout<<"Matrix A is not a square Matrix! Please check the data again."<<endl;
        return false;
    }
    
    
    double bigflag=0.0; // bigflag is used for storing the biggest value date in the matrix A to judge whether all of the items in a rows equals 0( in this case, |A|=0, ;
    for(long i=0;i< this->rows;i++)  //primary check the prerequisite for LU decomposition.
    {
        bigflag=0.0;
        for(long j=0;j<this->columns;j++)   //Becareful A.rows=A.columns! here is just for easy reading and understanding
         {
           //if(fabs(*(A.buf+A.rows*i+j))>bigflag)
			 if(fabs(this->buf[i*this->rows+j])>bigflag)
    
                //bigflag=*(A.buf+A.rows*i+j);    //to find the biggest value data in one row
				 bigflag=this->buf[i*this->rows+j]; 
         }
        if(bigflag==0.0)
          {
            cout<<"No nonzero largest element in the"<<i+1<<"th rows.(The det(A)=0, which does not meet the requestment of LU decomposition.)"<<endl;
            //" Matrix A may be a SINGULAR Matrix, which maybe can't be decomposed. Should be check again???"
          return false;
          }  
            
    }
    
    if(L.buf)  //if L have data, delete the data 
    {
        L.rows=L.columns=0;
        delete[] L.buf;
        L.buf=NULL; 
    }   //End of if L.buf... 
    if(U.buf)  //if U have data, delete the data 
    {
        U.rows=U.columns=0;
        delete[] U.buf;
        U.buf=NULL; 
    }   //End of if U.buf ...         
    
    L.rows=U.rows=this->rows;
    L.columns=U.columns=this->columns;  //set the L,U's rows and columns the same as the A's
    L.buf=new double[L.rows*L.columns];  //creat a buffer for storing the data 
    U.buf=new double[U.rows*U.columns];
    for(long i=0;i<L.rows;i++)
        for(long j=0;j<L.columns;j++)
        {
        *(L.buf+L.columns*i+j)=0.0;
        *(U.buf+U.columns*i+j)=0.0;        
        }    //init L,U=0;
        
    double sum=0.0; //temp varity used for store A[i][j] during the loop but init it to 0.0 here..
    
   // cout<<"LU decomposing.";    //if n=very large, then should to tell user I am running.
    for(long n=0;n<this->rows;n++)  //n used for A[n][n]
    {
        // all L[n][n] is assumed =1.0;
        for(long j=n;j<U.columns;j++)   // for caculating U[][j], the nth rows
        {   
            sum=*(this->buf+n*this->rows+j);    //here sum store A[n][j] 
            for(long k=0;k<n;k++)
                sum-=(*(L.buf+n*L.columns+k))*(*(U.buf+k*U.columns+j) );    
            *(U.buf+n*U.columns+j)=sum;    
        }
        
        for(long i=0;i<L.rows;i++)   //for caculating L[i][], the nth columns    
        {
            sum=*(this->buf+i*this->rows+n);    //here sum store A[n][j]
            for(long k=0;k<n;k++)
                sum-=(*(L.buf+i*L.rows+k))*(*(U.buf+k*U.rows+n) );
            if(*(U.buf+n*U.rows+n)==0)
                {   //if U[n][n]==0, then it means that A can not decomposed, for if U[n][n]=0, |A|=|L|*|U|=|L[n][n]|*|U[n][n]|=0, which can not meet the prerequisite of decomposing A;
                    cout<<"OOps, Zero in U["<<n<<"]["<<n<<"] is found, the matrix can not be decomposed. "<<endl;
                    L.rows=L.columns=0;
                    U.rows=U.columns=0;
                    delete[] L.buf;
                    L.buf=NULL; 
                    delete[] U.buf;
                    U.buf=NULL; //Clear all of the value is useful for other function who call LU(), and detect whether the operation of LU is successful.Also free all the memory.
                    return false;
                }
            else
                {
                    *(L.buf+i*L.rows+n)=sum*1.0/(*(U.buf+n*U.rows+n));
                }                
        }
        //cout<<".";
    }

	return true;

}
bool Matrix::QR(Matrix& Q, Matrix& R)
{
	if ((this->GetRows() == 0) || (this->GetRows() != this->GetColumns()))
                return false;
	Matrix tmp,tmp2,B;
	B = (*this);
	R = B.Identity((*this).GetRows());
	Q = B.Identity((*this).GetRows());
	tmp2 = (*this);
	for(int j=1;j<=(*this).GetColumns();j++)//main loop by column
		for(int i=1;i<=(*this).GetRows();i++)
		{
			if(i>j)//under the diagonal
				{
					//tmp = tmp2.MakeQij(i,j);
			tmp = B.Identity((*this).GetRows());
			tmp(i,i) = tmp2(j,j)/pow(tmp2(i,j)*tmp2(i,j)+tmp2(j,j)*tmp2(j,j),0.5);// c
			tmp(j,j) = tmp(i,i);// c
			tmp(i,j) = (-1) * tmp2(i,j)/pow(tmp2(i,j)*tmp2(i,j)+tmp2(j,j)*tmp2(j,j),0.5);// -s
				tmp(j,i) = (-1) * tmp(i,j); // s
					tmp2=tmp*tmp2;

					Q = tmp * Q;		
				}			
		}

	R = Q*(*this);//get R
	Q = Q.Transpose();//get Q

        return true;

}
double Matrix::det()//determinant(Matrix)
{
	//determinant
	
    if(this->rows!=this->columns)
       // throw logic_error ("Matrix has to be square to find det");
		   cerr << "Matrix has to be square to find det";
	if (this->rows==1&&this->columns==1)
	{
		//only one element
		return this->buf[0];
	}
	if(this->rows==2&&this->columns==2)
	{
		//square
		return ((this->buf[0])*(this->buf[3])-(this->buf[1])*(this->buf[2]));
	}

	/*��ǰ�ķ�����©��(LU�ֽ�����������)��������ʹ��
	int r=this->GetRows();	
	double tmp=1;
	Matrix L,U;
	this->LU(L,U);
	for(int i=0;i<r;i++)
		tmp=tmp*L.buf[i*r+i]*U.buf[i*r+i];
	return tmp;*/
	//������õݹ�ķ���
	//ǰ���Ѿ������������µ�����ʽ
	//������ʽ��0��չ��
	double num=0;
	int a=1;
	for (int i=1;i<=this->rows;i++)
	{
		num = num+a*(this->buf[i-1])*Minor(1,i);
		a=-a;
	}
	return num;
}
Matrix Matrix::Eigenvalues()//find the eigen values and store them in a vector (mx1 Matrix)
{
	if(this->IsSingular() || this->rows!=this->columns)  
		//throw logic_error ("Matrix has to be square and not singular");
			cerr << "Matrix has to be square and not singular";
	Matrix tmp,B,Q,R;
	int i,j,m=0;
	B=*this;
	tmp.rows=this->GetRows();
	tmp.columns=1;
	tmp.buf=new double(tmp.rows);
	while(m<=1)
	{
		B.QR(Q,R);
		B=R*Q;
		for(j=0;j<this->GetColumns();j++)
		{
			for(i=j+1;i<this->GetRows();i++)
			{
				if(B.buf[i*columns+j]<0.0000000001) continue;
				else
				{
					m=0;
					break;
				}
			}	
		}
	m++;	
	}
	for(i=0;i<this->GetRows();i++)	
	tmp.buf[i]=B.buf[i*columns+i];	
	return tmp;

}
Matrix Matrix::Root(const Matrix& b)//solving linear system of equations. b is actually a vector (mx1 Matrix) 
{
        if(b.rows!=this->GetRows() || this->det()==0)  
		//throw logic_error ("two matrices should have same rows and cannot be Singular");	
			cerr << "two matrices should have same rows and cannot be Singular";
	Matrix tmp;
	tmp=(this->Inverse());
	tmp=tmp*b;

	return tmp;
}
//------------------------------------------------------------------------------------------------
//operators, + - * can be overloaded as global operators

Matrix operator + (const Matrix& A, const Matrix& B) //Matrix A+B, using += .....
{
	Matrix tmp=A;
	tmp+=B;//use "+="
	return tmp;//   done
}

Matrix operator - (const Matrix& A, const Matrix& B) //Matrix A+B, using -= .....
{
	Matrix tmp=A;
	tmp-=B;//use "-="
	return tmp;//    done
}

Matrix operator * (const Matrix& A, const Matrix& B) //Matrix A+B, using *= .....
{
	Matrix tmp=A;
	tmp*=B;//use "*="
	return tmp;//    done
}


Matrix operator * (double a, const Matrix& A) //Matrix a*A, using *= .....
{
	Matrix tmp=A;
	//do a*A
        tmp*=a;
	return tmp;   //done
};


Matrix operator * (const Matrix& A, double a ) //Matrix A*a, using *= .....
{
	Matrix tmp=A;
	//do A*a
        tmp*=a;
	return tmp;
};

/**************************************************************************/
//��������
bool Matrix::ETOM_1(int row1,int row2)
{	
	int height = rows;
	int width = columns;
	double *temp1 = new double[width];
	double *temp2 = new double[width];
	double *buff = buf;
	memcpy(temp1,buff+row1*width,width*8);
	memcpy(temp2,buff+row2*width,width*8);
	//
	memcpy(buff+row2*width,temp1,width*8);
	memcpy(buff+row1*width,temp2,width*8);

	delete[]temp1;
	delete[]temp2;
	return true;
}
//����
bool Matrix::ETOM_2(int row,double scalar)
{
	//int height = rows;
	int width = columns;
	int i=0;//
	double *temp1 = new double[width];
	double *tempBuf = buf;
	memcpy(temp1,tempBuf+row*width,width*8);
	for (i=0;i<width;i++)
	{
		*(tempBuf+row*width+i) = *(temp1+i)*scalar;
	}
	delete[]temp1;
	return true;
}
//ĳһ�еĶ�ӦԪ��*scalar�ӵ���һ��
bool Matrix::ETOM_3(int row1,double scalar,int row2)
{
	int height = rows;
	int width = columns;
	double *temp1 = new double[width];
	double *temp2 = new double[width];
	double *buff = buf;
	memcpy(temp1,buff+row1*width,width*8);
	memcpy(temp2,buff+row2*width,width*8);
	int i=0;
	for (i=0;i<width;i++)
	{
		*(buff+row2*width+i) = *(temp1+i)*scalar+*(temp2+i);
	}
	delete[]temp1;
	delete[]temp2;
	return true;
	return true;
}
//���ó����б任��������
bool Matrix::ETOM_Inverse()
 {
	 //�����µľ���
	 int height = rows;
	 int width = columns*2;
	 double *buf_src = buf;
	 double *buf_temp = new double[rows*columns*2];
	 double *E = new double[rows*columns];
	 //
	// memset(buf_temp,0,rows*columns*2*8);
	 int i=0,j=0;
	 //ΪE��λ����ֵ
	 for (i=0;i<rows;i++)
	 {
		 for (j=0;j<columns;j++)
		 {
			 if (i==j)
			 {
				 *(E+i*columns+j)=1;
			 }
			 else
			 {
				 *(E+i*columns+j)=0;
			 }

		 }
	 }
	 //Matrix EE(rows,columns,E);
	 //cout<<EE<<endl;
	 //Ϊ�µľ���ֵ
	 for (i=0;i<height;i++)
	 {
		 for (j=0;j<width;j++)
		 {
			 if (j<columns)
			 {
				 *(buf_temp+i*width+j) = *(buf_src+i*columns+j);
			 }
			 else
			 {
				 *(buf_temp+i*width+j) = *(E+i*columns+j-columns);
			 }
		 }
	 }
	 //�õ��������
	 Matrix B(height,width,buf_temp);
	// cout<<B<<endl;
	 B.ETOM_InvsCall();	
	 //cout<<B<<endl;
	 double *buf_B = B.buf;
	 //cout<<B.buf[0]<<endl;
	 //Ϊ�õ��������ֵ
	 for (i=0;i<rows;i++)
	 {
		 for (j=0;j<columns;j++)
		 {
			*(buf_src+i*rows+j) = *(buf_B+i*width+j+columns);
		 }
	 }

	 delete[]buf_temp;
	 delete[]E;
	 return true;
 }
//ETOM_InverseҪ���õĺ����������������б任
 bool Matrix::ETOM_InvsCall()
 {
	 int height = rows;
	 int width = columns;
	 int i,j;
	 double *buf_temp=buf;
	 double k=0;
	 for (j=0;j<height;j++)
	 {//��height
		 for (i=j;i<height;i++)
		 {
			//j�ֱ����0 1 2
			 if (abs(*(buf_temp+i*width+j))>1e-4)
			 {
				 //��Ϊ0
				 if (i==j)
				 {
					 break;
				 }
				 else
				 {
					 this->ETOM_1(j,i);
					 break;
				 }
			 }
		 }
		 //�õ�ָ���еĶԽ����ϵ�Ԫ�ز�Ϊ0
		 k=1/(*(buf_temp+j*width+j));//ȡĳһ��ĳһ��Ԫ�صĵ���
		 this->ETOM_2(j,k);//�൱�ڹ�һ��
		 //��Ԫ
		 if (j<height-1)
		 {
			 for (i=j+1;i<height;i++)
			 {
				 if (abs(*(buf_temp+i*width+j))>1e-4)
				 {
					 //��Ϊ0
					 k = -(*(buf_temp+i*width+j));
					 this->ETOM_3(j,k,i);
				 }
			 }
		 }
	 }

	 //
	 for (i=height-2;i>=0;i--)
	 {
		 //
		 for (j=i+1;j<width/2;j++)
		 {
			 if (abs(*(buf_temp+i*width+j))>1e-4)
			 {
				 //��Ϊ0
				 k = -(*(buf_temp+i*width+j));
				 this->ETOM_3(j,k,i);
			 }
		 }
	 }
	 return true;
/*
	 for (i=0;i<height;i++)
	 {
		 if (abs(*(buf_temp+i*width+0))>1e-4)
		 {
			 //��Ϊ0
			 if (i==0)
			 {
				 break;
			 }
			 else
			 {
				 this->ETOM_1(0,i);
				 break;
			 }
		 }
	 }
	 //�õ���һ��Ԫ�ز�Ϊ0 ���������
	 k=1/(*(buf_temp+0*width+0));//ȡĳһ��ĳһ��Ԫ�صĵ���
	 this->ETOM_2(0,k);//�൱�ڹ�һ��
	 for (i=1;i<height;i++)
	 {
		 if (abs(*(buf_temp+i*width+0))>1e-4)
		 {
			 //��Ϊ0
			 k = -(*(buf_temp+i*width+0));
			 this->ETOM_3(0,k,i);
		 }
	 }
	 //
	 for (i=1;i<height;i++)
	 {
		 if (abs(*(buf_temp+i*width+1))>1e-4)
		 {
			  //��Ϊ0
			 if (i==1)
			 {
				 break;
			 }
			 else
			 {
				 this->ETOM_1(1,i);
				 break;
			 }
		 }
	 }

	 //
	 k=1/(*(buf_temp+1*width+1));//ȡĳһ��ĳһ��Ԫ�صĵ���
	 this->ETOM_2(1,k);//�൱�ڹ�һ��

	 for (i=2;i<height;i++)
	 {
		 if (abs(*(buf_temp+i*width+1))>1e-4)
		 {
			 //��Ϊ0
			 k = -(*(buf_temp+i*width+1));
			 this->ETOM_3(1,k,i);
		 }
	 }
	 k=1/(*(buf_temp+2*width+2));//ȡĳһ��ĳһ��Ԫ�صĵ���
	 this->ETOM_2(2,k);//�൱�ڹ�һ��
	 //�õ��˶Խ����ϵ�Ԫ�ض���1
	 */

	
 }
bool Matrix::L_U(Matrix& L, Matrix& U)
{

	int height = this->rows;
	int width = this->columns;
	double *buf_src = this->buf;
	//
	if(this->rows!=this->columns)   //LU decomposition only can be operated on square Matrix
	{
		cout<<"Matrix A is not a square Matrix! Please check the data again."<<endl;
		return false;
	}
	//���ڼ���þ���ĸ���˳������ʽ��������0  ������detȥ��

	if(L.buf)  //if L have data, delete the data 
	{
		L.rows=L.columns=0;
		delete[] L.buf;
		L.buf=NULL; 
	}   //End of if L.buf... 
	if(U.buf)  //if U have data, delete the data 
	{
		U.rows=U.columns=0;
		delete[] U.buf;
		U.buf=NULL; 
	}   //End of if U.buf ...         

	L.rows=U.rows=this->rows;
	L.columns=U.columns=this->columns;  //set the L,U's rows and columns the same as the A's
	L.buf=new double[L.rows*L.columns];  //creat a buffer for storing the data 
	U.buf=new double[U.rows*U.columns];
	int i=0,j=0;
	double *buf_L = L.buf;
	double *buf_U = U.buf;
	for( i=0;i<L.rows;i++)
		for( j=0;j<L.columns;j++)
		{
			*(L.buf+L.columns*i+j)=0.0;
			*(U.buf+U.columns*i+j)=0.0;        
		}    //init L,U=0;
		for (i=0;i<height;i++)
		{
			*(buf_L+i*width+0) = *(buf_src+i*width+0);
			*(buf_U+i*width+i) = 1.0;
		}
		//
		double sum=0;
		int s=0;
		//*****************
		for (int i=0;i<height-1;i++)
		{
			for (j=i+1;j<height;j++)
			{
				if (i==0)
				{
					*(buf_U+i*width+j) = *(buf_src+i*width+j)/(*(buf_L+0*width+0));
				}
				else
				{
					sum=0;
					for (s=0;s<j;s++)
					{
						sum+=*(buf_L+i*width+s)*(*(buf_U+s*width+j));
					}
					sum=(*(buf_src+i*width+j)-sum)/(*(buf_L+i*width+i));
					*(buf_U+i*width+j) = sum;
				}
			}
			for (j=1;j<=i+1;j++)
			{

				sum=0;
				for (s=0;s<j;s++)
				{
					sum+=*(buf_L+(i+1)*width+s)*(*(buf_U+s*width+j));
				}
				sum=*(buf_src+(i+1)*width+j)-sum;
				*(buf_L+(i+1)*width+j) = sum;
			}
		}
	return true;
}
//Ϊ�Խ����ϵ�Ԫ�ظ�ֵ
void Matrix::SetIdentity(double value)
{
	int height = this->rows;
	int width = this->columns;
	double *buf_src = this->buf;
	int i,j;
	for (i=0;i<height;i++)
	{
		for (j=0;j<width;j++)
		{
			if (i==j)
			{
				*(buf_src+i*width+j)=value;
			}
			else
			{
				*(buf_src+i*width+j)=0;
			}
		}
	}
}
void Matrix::SetZero()
{
	int height = this->rows;
	int width = this->columns;
	double *buf_src = this->buf;
	int i,j;
	for (i=0;i<height;i++)
	{
		for (j=0;j<width;j++)
		{
			*(buf_src+i*width+j)=0;
		}
	}
}
/**************************************************************************/
